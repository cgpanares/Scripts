import sys
import os
import time
from time import sleep
from deepsecurity.rest import ApiException

def DeleteComputer(api, apiversion, ComputerInventory):
    compIDlist = []
    compNameList = []
    compIDNameList = []
    print("Menu 5 - Delete a Computer")
    inputFirstChoice = input("Enter 1 if you want to see the list first or 2 if you want to delete via Hostname: ")
    if inputFirstChoice == "1":
        print("List of Computers")
        for computers in ComputerInventory.computers:
                print(str(computers.id) + " - " + computers.host_name)
                compIDlist.append(str(computers.id))
        inputID = input("Enter ID you wish to delete: ")
        choiceID = int(inputID)
        try:
            if inputID in compIDlist:
                sleep(2)
                api.delete_computer(choiceID, apiversion)
                print("Successfully deleted ID: " + inputID)
            else:
                print("ID does not exist!")
        except ApiException as e:
            print("An exception occurred when calling ComputersApi.delete_computer: %s\n" % e)
    
    elif inputFirstChoice == "2":
        inputName = input("Enter hostname you wish to delete: ")
        for computers in ComputerInventory.computers:
               if computers.host_name == inputName:
                    compNameList.append(str(computers.id))
                    compIDNameList.append(str(computers.host_name))
        try:
            if inputName in compIDNameList:
                for choiceID in compNameList:
                    api.delete_computer(choiceID, apiversion)
                print("Successfully deleted Hostname: " + inputName)
            else:
                print("Hostname does not exist!")
        except ApiException as e:
            print("An exception occurred when calling ComputersApi.delete_computer: %s\n" % e)
            
    else:
        print("Wrong input!")