import sys
import os
import time
from time import sleep
from xlwt import Workbook
import pyexcel as p
import datetime

wb = Workbook()
sheet1 = wb.add_sheet("Deep Security Agent Report", cell_overwrite_ok=True)


def SearchComputer(ComputerInventory):
            x = 0
            computerList = []
            print("Menu 2 - Search a Computer")
            inputName = input("Enter Hostname: ")
            for computerA in ComputerInventory.computers:
                computerList.append(computerA.host_name)
            if inputName in str(computerList):
                sleep(3)
                for computer in ComputerInventory.computers:
                    if inputName in str(computer.host_name):
                        print("Hostname: " + computer.host_name)
                        print("Platform: " + computer.platform)
                        print("Agent Version: " + computer.agent_version)
                        print("Status: " + str(computer.computer_status.agent_status_messages))
                        print("Anti-Malware State: " + str(computer.anti_malware.module_status.agent_status_message))
                        if str(computer.anti_malware.last_manual_scan) != "None":
                            rawtime = str(computer.anti_malware.last_manual_scan)
                            splitrt = rawtime[:-3]
                            sheet1.write(x, 0, "Anti-Malware Last Manual Scan: ")
                            sheet1.write(x, 1, datetime.datetime.fromtimestamp(int(splitrt)).strftime('%Y-%m-%d %H:%M:%S'))
                            x+=1
                        else:
                            sheet1.write(x, 0, "Anti-Malware Last Manual Scan: ")
                            sheet1.write(x, 1, str(computer.anti_malware.last_manual_scan))
                            x+=1
                        if str(computer.anti_malware.last_scheduled_scan) != "None":
                            rawtime = str(computer.anti_malware.last_scheduled_scan)
                            splitrt = rawtime[:-3]
                            sheet1.write(x, 0, "Anti-Malware Last Scheduled Scan: ")
                            sheet1.write(x, 1, datetime.datetime.fromtimestamp(int(splitrt)).strftime('%Y-%m-%d %H:%M:%S'))
                            x+=1
                        else:
                            sheet1.write(x, 0, "Anti-Malware Last Scheduled Scan: ")
                            sheet1.write(x, 1, str(computer.anti_malware.last_scheduled_scan))
                        for su in computer.security_updates.anti_malware:
                            print("Name: " + str(su.name) + " Version: " + str(su.version) + " is this latest?: " + str(su.latest))
                        print("#-------------------------------------------------#")
            else:
                sleep(3)
                print("Hostname does not exist!")
            print("Done!")
            print()