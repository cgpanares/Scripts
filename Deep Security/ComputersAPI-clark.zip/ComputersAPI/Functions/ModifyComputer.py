from __future__ import print_function
import sys
import os
import time
from time import sleep
from deepsecurity.rest import ApiException

def ModifyComputer(api, apiversion, ComputerInventory, api_c):
    computerList = []
    computerID = None
    def change_computer_name(hostname, desired_setting, old_setting, new_setting):
                computer = api_c.Computer()
                if desired_setting == "host_name":
                    computer.host_name = new_setting
                elif desired_setting == "display_name" :
                    computer.display_name = new_setting
                elif desired_setting == "description" :
                    computer.description = new_setting
                elif desired_setting == "group_id":
                    computer.group_id = new_setting
                elif desired_setting == "policy_id":
                    computer.policy_id = new_setting
                elif desired_setting == "asset_importance_id":
                    computer.asset_importance_id = new_setting
                elif desired_setting == "relay_list_id":
                    computer.relay_list_id = new_setting
                elif desired_setting == "bios_uuid":
                    computer.bios_uuid = new_setting
                elif desired_setting == "id":
                    computer.id = new_setting
                elif desired_setting == "external_id":
                    computer.external_id = new_setting
                elif desired_setting == "platform_setting_relay_state.value":
                    computer.computer_settings.platform_setting_relay_state.value = new_setting
                
                try:
                    api.modify_computer(computerID, computer, apiversion, overrides=False)
                    print(f'Successfully changed setting of "{hostname}" setting for "{desired_setting}" from "{old_setting}" to "{new_setting}".')
        
                except ApiException as e:
                    print("An exception occurred when calling ComputersApi.modify_computer: %s\n" % e)
                    
    print("Menu 6 - Modify a Computer")
    inputHostname = input("Enter Hostname of the machine you want to modify: ")
    for computer in ComputerInventory.computers:
        if computer.host_name == inputHostname:
            computerList.append(str(computer.host_name))
            computerID = str(computer.id)
            
        
    if inputHostname in computerList:
            inputSetting = input("Enter setting you wish to modify: ")
            inputOldValue = input("Enter Old Value: ")
            inputNewValue = input("Enter New Value: ")
            change_computer_name(inputHostname, inputSetting, inputOldValue, inputNewValue)
    else:
            print("Hostname does not exist!")
