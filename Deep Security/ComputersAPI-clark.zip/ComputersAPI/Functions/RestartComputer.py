import sys
import os
import time
from time import sleep


def RestartComputer(ComputerInventory):
            computerListS = []
            rebootList = []
            print("Check for reboot required status... ")
            for computerR in ComputerInventory.computers:
                computerListS.append(computerR.computer_status)
            if "Reboot" in str(computerListS):
                sleep(3)
                for computer in ComputerInventory.computers:
                    if "Reboot" in str(computer.computer_status):
                        rebootList.append(computer.host_name)
                print("Number of machines: ", len(rebootList))
                inputReboot = input("Do you want to see the hostnames that requires a reboot?(y/n): ")
                print()
                if "y" in inputReboot:
                    for r in rebootList:
                        print(r)
                    print()
                else:
                    print("Aborted.")
                print("Done!")
                print()
            else:
                sleep(3)
                print("None.")
                print()